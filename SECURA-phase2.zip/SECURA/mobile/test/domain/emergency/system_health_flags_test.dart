import 'package:flutter_test/flutter_test.dart';
import 'package:secura/domain/domain.dart';

void main() {
  group('SystemHealthFlags', () {
    test('defaults to all-clear', () {
      const flags = SystemHealthFlags();
      expect(flags.isDegraded, isFalse);
    });

    test('isDegraded is true if any flag is set', () {
      const flags = SystemHealthFlags(lowBattery: true);
      expect(flags.isDegraded, isTrue);
    });

    test('copyWith only changes the given fields', () {
      const flags = SystemHealthFlags(sensorUnavailable: true);
      final updated = flags.copyWith(lowBattery: true);

      expect(updated.sensorUnavailable, isTrue);
      expect(updated.lowBattery, isTrue);
      expect(updated.networkUnavailable, isFalse);
    });

    test('equal flags compare equal', () {
      const a = SystemHealthFlags(networkUnavailable: true);
      const b = SystemHealthFlags(networkUnavailable: true);

      expect(a, equals(b));
      expect(a.hashCode, equals(b.hashCode));
    });
  });
}
