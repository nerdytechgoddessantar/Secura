import 'package:flutter_test/flutter_test.dart';
import 'package:secura/domain/domain.dart';

void main() {
  group('EmergencyStateMachine — happy paths', () {
    test('user confirms safe and returns to normal', () {
      final machine = EmergencyStateMachine();

      machine.fire(EmergencyEvent.riskScoreExceededThreshold);
      expect(machine.state, EmergencyState.possibleDistress);

      machine.fire(EmergencyEvent.checkInTriggered);
      expect(machine.state, EmergencyState.checkingIn);

      machine.fire(EmergencyEvent.userConfirmedSafe);
      expect(machine.state, EmergencyState.userConfirmedSafe);

      machine.fire(EmergencyEvent.acknowledged);
      expect(machine.state, EmergencyState.normal);

      expect(machine.history, hasLength(4));
    });

    test('user requests help and the emergency resolves', () {
      final machine = EmergencyStateMachine(
        initialState: EmergencyState.checkingIn,
      );

      machine.fire(EmergencyEvent.userRequestedHelp);
      expect(machine.state, EmergencyState.userRequestedHelp);

      machine.fire(EmergencyEvent.acknowledged);
      expect(machine.state, EmergencyState.emergencyActive);

      machine.fire(EmergencyEvent.emergencyResolved);
      expect(machine.state, EmergencyState.resolved);

      machine.fire(EmergencyEvent.returnedToNormal);
      expect(machine.state, EmergencyState.normal);
    });

    test('no response within the timeout escalates to an emergency', () {
      final machine = EmergencyStateMachine(
        initialState: EmergencyState.checkingIn,
      );

      machine.fire(EmergencyEvent.checkInTimedOut);
      expect(machine.state, EmergencyState.emergencyActive);
    });

    test('an emergency that turns out to be false resets cleanly', () {
      final machine = EmergencyStateMachine(
        initialState: EmergencyState.emergencyActive,
      );

      machine.fire(EmergencyEvent.markedFalseAlarm);
      expect(machine.state, EmergencyState.falseAlarm);

      machine.fire(EmergencyEvent.returnedToNormal);
      expect(machine.state, EmergencyState.normal);
    });

    test('dismissing a possible-distress prompt cancels it', () {
      final machine = EmergencyStateMachine(
        initialState: EmergencyState.possibleDistress,
      );

      machine.fire(EmergencyEvent.userDismissed);
      expect(machine.state, EmergencyState.cancelled);

      machine.fire(EmergencyEvent.returnedToNormal);
      expect(machine.state, EmergencyState.normal);
    });

    test('risk score decaying before a check-in returns to normal', () {
      final machine = EmergencyStateMachine(
        initialState: EmergencyState.possibleDistress,
      );

      machine.fire(EmergencyEvent.riskScoreDecayed);
      expect(machine.state, EmergencyState.normal);
    });
  });

  group('EmergencyStateMachine — invalid transitions', () {
    test('rejects an event with no transition from the current state', () {
      final machine = EmergencyStateMachine();

      expect(
        () => machine.fire(EmergencyEvent.userConfirmedSafe),
        throwsA(isA<InvalidEmergencyTransition>()),
      );
      // A rejected transition must not change state or history.
      expect(machine.state, EmergencyState.normal);
      expect(machine.history, isEmpty);
    });

    test('canFire reports validity without mutating state', () {
      final machine = EmergencyStateMachine();

      expect(
        machine.canFire(EmergencyEvent.riskScoreExceededThreshold),
        isTrue,
      );
      expect(machine.canFire(EmergencyEvent.checkInTimedOut), isFalse);
      expect(machine.state, EmergencyState.normal);
    });
  });

  group('EmergencyStateMachine — history', () {
    test('records from/event/to/timestamp using the injected clock', () {
      final times = [
        DateTime.utc(2026, 1, 1, 12, 0),
        DateTime.utc(2026, 1, 1, 12, 1),
      ];
      var i = 0;
      final machine = EmergencyStateMachine(clock: () => times[i++]);

      machine.fire(EmergencyEvent.riskScoreExceededThreshold);
      machine.fire(EmergencyEvent.checkInTriggered);

      expect(machine.history[0].from, EmergencyState.normal);
      expect(
        machine.history[0].event,
        EmergencyEvent.riskScoreExceededThreshold,
      );
      expect(machine.history[0].to, EmergencyState.possibleDistress);
      expect(machine.history[0].timestamp, times[0]);

      expect(machine.history[1].to, EmergencyState.checkingIn);
      expect(machine.history[1].timestamp, times[1]);
    });

    test('history is unmodifiable from the outside', () {
      final machine = EmergencyStateMachine();
      expect(
        () => machine.history.add(
          EmergencyTransition(
            from: EmergencyState.normal,
            event: EmergencyEvent.riskScoreExceededThreshold,
            to: EmergencyState.possibleDistress,
            timestamp: DateTime.now(),
          ),
        ),
        throwsUnsupportedError,
      );
    });
  });
}
