import 'package:flutter_test/flutter_test.dart';
import 'package:secura/domain/domain.dart';

void main() {
  group('SignalContribution', () {
    test('stores its fields', () {
      const contribution = SignalContribution(
        signalName: 'heart_rate_spike',
        contribution: 0.4,
        rawValue: 142,
        threshold: 120,
      );

      expect(contribution.signalName, 'heart_rate_spike');
      expect(contribution.contribution, 0.4);
      expect(contribution.rawValue, 142);
      expect(contribution.threshold, 120);
    });

    test('two contributions with the same values are equal', () {
      const a = SignalContribution(
        signalName: 'route_deviation',
        contribution: 0.3,
        rawValue: 250.0,
      );
      const b = SignalContribution(
        signalName: 'route_deviation',
        contribution: 0.3,
        rawValue: 250.0,
      );

      expect(a, equals(b));
      expect(a.hashCode, equals(b.hashCode));
    });

    test('rejects a contribution outside [0.0, 1.0]', () {
      expect(
        () => SignalContribution(
          signalName: 'bad',
          contribution: 1.5,
          rawValue: null,
        ),
        throwsA(isA<AssertionError>()),
      );
    });
  });

  group('RiskResult', () {
    final timestamp = DateTime.utc(2026, 1, 1, 12);

    test('exposes an unmodifiable triggeredSignals list', () {
      final result = RiskResult(
        score: 0.6,
        confidence: 0.9,
        triggeredSignals: const [
          SignalContribution(
            signalName: 'heart_rate_spike',
            contribution: 0.6,
            rawValue: 150,
          ),
        ],
        timestamp: timestamp,
        recommendation: Recommendation.checkIn,
      );

      expect(result.triggeredSignals, hasLength(1));
      expect(
        () => result.triggeredSignals.add(
          const SignalContribution(
            signalName: 'x',
            contribution: 0.1,
            rawValue: null,
          ),
        ),
        throwsUnsupportedError,
      );
    });

    test('two results with equal fields are equal', () {
      const signal = SignalContribution(
        signalName: 'fall_detected',
        contribution: 1.0,
        rawValue: true,
      );

      final a = RiskResult(
        score: 1.0,
        confidence: 0.8,
        triggeredSignals: const [signal],
        timestamp: timestamp,
        recommendation: Recommendation.escalate,
      );
      final b = RiskResult(
        score: 1.0,
        confidence: 0.8,
        triggeredSignals: const [signal],
        timestamp: timestamp,
        recommendation: Recommendation.escalate,
      );

      expect(a, equals(b));
      expect(a.hashCode, equals(b.hashCode));
    });

    test('rejects a score outside [0.0, 1.0]', () {
      expect(
        () => RiskResult(
          score: 1.2,
          confidence: 0.5,
          triggeredSignals: const [],
          timestamp: timestamp,
          recommendation: Recommendation.none,
        ),
        throwsA(isA<AssertionError>()),
      );
    });

    test('rejects a confidence outside [0.0, 1.0]', () {
      expect(
        () => RiskResult(
          score: 0.5,
          confidence: -0.1,
          triggeredSignals: const [],
          timestamp: timestamp,
          recommendation: Recommendation.none,
        ),
        throwsA(isA<AssertionError>()),
      );
    });
  });
}
