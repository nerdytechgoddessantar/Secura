/// Barrel export for SECURA's domain layer — pure Dart, no Flutter and
/// no I/O. See docs/ARCHITECTURE.md §4–§6 for what lives here and why.
library;

export 'emergency/emergency_event.dart';
export 'emergency/emergency_state.dart';
export 'emergency/emergency_state_machine.dart';
export 'emergency/system_health_flags.dart';
export 'entities/recommendation.dart';
export 'entities/risk_result.dart';
export 'entities/signal_contribution.dart';
