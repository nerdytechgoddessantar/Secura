/// Events that drive transitions in `EmergencyStateMachine`.
///
/// Events describe *what happened*, not what state to go to — the
/// machine's transition table (docs/ARCHITECTURE.md §6) owns that
/// mapping, so the same event can mean different things depending on
/// the current state. For example, [userDismissed] is valid from both
/// `possibleDistress` and `checkingIn`, and [acknowledged] settles
/// `userConfirmedSafe` to `normal` but settles `userRequestedHelp` to
/// `emergencyActive` (see `EmergencyState`).
enum EmergencyEvent {
  /// The Risk Detection Engine's score crossed the check-in threshold.
  riskScoreExceededThreshold,

  /// The risk score dropped back down before a check-in was needed.
  riskScoreDecayed,

  /// The Check-in System is showing "Are you safe?".
  checkInTriggered,

  /// The user dismissed a prompt without confirming safety or asking
  /// for help.
  userDismissed,

  /// The user tapped "I'm Safe".
  userConfirmedSafe,

  /// The user tapped "I Need Help".
  userRequestedHelp,

  /// No response arrived within the configured check-in timeout.
  checkInTimedOut,

  /// Internal bookkeeping transition: a transient
  /// confirmation/help-request state has been acknowledged and the
  /// machine should settle into its resulting state.
  acknowledged,

  /// The emergency situation has been closed out for real.
  emergencyResolved,

  /// The emergency turned out not to be real.
  markedFalseAlarm,

  /// Returning to normal monitoring after `cancelled`, `falseAlarm`, or
  /// `resolved` (see `EmergencyState`).
  returnedToNormal,
}
