/// The Emergency State Machine's primary states (docs/ARCHITECTURE.md
/// §6).
///
/// This is the single authority on what SECURA is currently doing.
/// Every other component reacts to state changes; nothing else is
/// allowed to mutate state directly — always go through
/// `EmergencyStateMachine.fire`.
///
/// System-health conditions (sensor dropped, no network, low battery)
/// are deliberately *not* represented here — see `SystemHealthFlags`
/// for why they're tracked as orthogonal flags instead.
enum EmergencyState {
  /// Nothing unusual is happening.
  normal,

  /// The Risk Detection Engine flagged an elevated score, but no
  /// check-in has been triggered yet.
  possibleDistress,

  /// "Are you safe?" is showing, waiting for a response or a timeout.
  checkingIn,

  /// The user answered "I'm Safe". Transient — settles to [normal].
  userConfirmedSafe,

  /// The user answered "I Need Help". Transient — settles to
  /// [emergencyActive].
  userRequestedHelp,

  /// The emergency workflow is running: contacts notified, location
  /// shared, an emergency event created.
  emergencyActive,

  /// An emergency was real and has been closed out.
  resolved,

  /// An emergency was triggered but turned out not to be real.
  falseAlarm,

  /// The user dismissed a possible-distress or check-in prompt before
  /// anything escalated.
  cancelled,
}
