/// Orthogonal system-health conditions that can be true in *any* primary
/// emergency state at once (docs/ARCHITECTURE.md §6) — for example, the
/// app can be running an active emergency and be low on battery at the
/// same time. Modeling these as flags instead of extra states keeps the
/// primary state machine small and avoids a combinatorial explosion of
/// states.
class SystemHealthFlags {
  const SystemHealthFlags({
    this.sensorUnavailable = false,
    this.networkUnavailable = false,
    this.lowBattery = false,
  });

  /// A required sensor feed (phone or wearable) has dropped.
  final bool sensorUnavailable;

  /// No network connectivity — emergency actions should queue rather
  /// than fail silently.
  final bool networkUnavailable;

  /// Phone or watch battery is critical — the Emergency Response System
  /// should prioritize location-sharing over less time-critical
  /// actions.
  final bool lowBattery;

  /// True if any of the flags above are set.
  bool get isDegraded =>
      sensorUnavailable || networkUnavailable || lowBattery;

  SystemHealthFlags copyWith({
    bool? sensorUnavailable,
    bool? networkUnavailable,
    bool? lowBattery,
  }) {
    return SystemHealthFlags(
      sensorUnavailable: sensorUnavailable ?? this.sensorUnavailable,
      networkUnavailable: networkUnavailable ?? this.networkUnavailable,
      lowBattery: lowBattery ?? this.lowBattery,
    );
  }

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is SystemHealthFlags &&
          runtimeType == other.runtimeType &&
          sensorUnavailable == other.sensorUnavailable &&
          networkUnavailable == other.networkUnavailable &&
          lowBattery == other.lowBattery);

  @override
  int get hashCode =>
      Object.hash(sensorUnavailable, networkUnavailable, lowBattery);

  @override
  String toString() =>
      'SystemHealthFlags(sensorUnavailable: $sensorUnavailable, '
      'networkUnavailable: $networkUnavailable, lowBattery: $lowBattery)';
}
