import 'emergency_event.dart';
import 'emergency_state.dart';

/// Thrown when `EmergencyStateMachine.fire` is called with an event that
/// has no defined transition from the machine's current state.
///
/// This is intentionally a hard failure rather than a silent no-op: an
/// unexpected transition attempt almost always means a bug upstream
/// (e.g. the UI offering "I'm Safe" from a screen that shouldn't be
/// showing it), and silently swallowing that would be far more
/// dangerous in a safety app than failing loudly in development and
/// testing.
class InvalidEmergencyTransition implements Exception {
  const InvalidEmergencyTransition(this.currentState, this.event);

  final EmergencyState currentState;
  final EmergencyEvent event;

  @override
  String toString() =>
      'InvalidEmergencyTransition: event $event has no defined '
      'transition from state $currentState';
}

/// A single recorded transition, kept for the Emergency History screen
/// and for tests.
class EmergencyTransition {
  EmergencyTransition({
    required this.from,
    required this.event,
    required this.to,
    required this.timestamp,
  });

  final EmergencyState from;
  final EmergencyEvent event;
  final EmergencyState to;
  final DateTime timestamp;

  @override
  String toString() => 'EmergencyTransition($from --$event--> $to '
      '@ $timestamp)';
}

/// The single authority on SECURA's emergency state
/// (docs/ARCHITECTURE.md §6). Every other component reacts to state
/// changes here; nothing else is allowed to mutate state directly.
///
/// System-health conditions (see `SystemHealthFlags`) are deliberately
/// *not* part of this machine's states: they're orthogonal and tracked
/// separately, so e.g. an active emergency and a low battery can both
/// be true at once without doubling the state count.
class EmergencyStateMachine {
  EmergencyStateMachine({
    EmergencyState initialState = EmergencyState.normal,
    DateTime Function()? clock,
  }) : _state = initialState,
       _clock = clock ?? DateTime.now;

  final DateTime Function() _clock;

  /// The full set of valid transitions. This table — not scattered
  /// if/else logic — is the one place that defines what SECURA's
  /// emergency flow can do. See docs/ARCHITECTURE.md §6 for the
  /// diagram this encodes.
  static const Map<EmergencyState, Map<EmergencyEvent, EmergencyState>>
  _transitions = {
    EmergencyState.normal: {
      EmergencyEvent.riskScoreExceededThreshold:
          EmergencyState.possibleDistress,
    },
    EmergencyState.possibleDistress: {
      EmergencyEvent.checkInTriggered: EmergencyState.checkingIn,
      EmergencyEvent.riskScoreDecayed: EmergencyState.normal,
      EmergencyEvent.userDismissed: EmergencyState.cancelled,
    },
    EmergencyState.checkingIn: {
      EmergencyEvent.userConfirmedSafe: EmergencyState.userConfirmedSafe,
      EmergencyEvent.userRequestedHelp: EmergencyState.userRequestedHelp,
      EmergencyEvent.checkInTimedOut: EmergencyState.emergencyActive,
      EmergencyEvent.userDismissed: EmergencyState.cancelled,
    },
    EmergencyState.userConfirmedSafe: {
      EmergencyEvent.acknowledged: EmergencyState.normal,
    },
    EmergencyState.userRequestedHelp: {
      EmergencyEvent.acknowledged: EmergencyState.emergencyActive,
    },
    EmergencyState.emergencyActive: {
      EmergencyEvent.emergencyResolved: EmergencyState.resolved,
      EmergencyEvent.markedFalseAlarm: EmergencyState.falseAlarm,
    },
    EmergencyState.resolved: {
      EmergencyEvent.returnedToNormal: EmergencyState.normal,
    },
    EmergencyState.falseAlarm: {
      EmergencyEvent.returnedToNormal: EmergencyState.normal,
    },
    EmergencyState.cancelled: {
      EmergencyEvent.returnedToNormal: EmergencyState.normal,
    },
  };

  EmergencyState _state;
  final List<EmergencyTransition> _history = [];

  /// The machine's current state. Read-only from the outside — the
  /// only way to change it is [fire].
  EmergencyState get state => _state;

  /// Every transition this machine has made, oldest first.
  /// Unmodifiable snapshot at the time of access.
  List<EmergencyTransition> get history => List.unmodifiable(_history);

  /// Whether [event] has a defined transition from the current state,
  /// without actually applying it. Callers (e.g. the UI deciding which
  /// buttons to show) should use this rather than guessing.
  bool canFire(EmergencyEvent event) =>
      _transitions[_state]?.containsKey(event) ?? false;

  /// Applies [event] to the current state.
  ///
  /// Throws [InvalidEmergencyTransition] if there's no defined
  /// transition for [event] from the current state — see that class's
  /// docs for why this fails loudly instead of silently ignoring the
  /// call. On failure, neither [state] nor [history] change.
  EmergencyState fire(EmergencyEvent event) {
    final nextState = _transitions[_state]?[event];
    if (nextState == null) {
      throw InvalidEmergencyTransition(_state, event);
    }
    final from = _state;
    _state = nextState;
    _history.add(
      EmergencyTransition(
        from: from,
        event: event,
        to: nextState,
        timestamp: _clock(),
      ),
    );
    return _state;
  }
}
