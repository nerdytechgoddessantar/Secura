import 'recommendation.dart';
import 'signal_contribution.dart';

/// The output contract of the Risk Detection Engine (docs/ARCHITECTURE.md
/// §5).
///
/// [RiskResult] is a pure value object: the engine that produces it is a
/// pure function of normalized sensor data, with no side effects. That's
/// what makes both the engine and this class independently
/// unit-testable, and what will let a future ML model be swapped in
/// later without changing anything downstream.
class RiskResult {
  RiskResult({
    required this.score,
    required this.confidence,
    required List<SignalContribution> triggeredSignals,
    required this.timestamp,
    required this.recommendation,
  }) : assert(score >= 0.0 && score <= 1.0, 'score must be in [0.0, 1.0]'),
       assert(
         confidence >= 0.0 && confidence <= 1.0,
         'confidence must be in [0.0, 1.0]',
       ),
       triggeredSignals = List.unmodifiable(triggeredSignals);

  /// Overall unusualness of the current sensor window, in [0.0, 1.0].
  /// This is not a probability of danger — see docs/ARCHITECTURE.md §1.
  final double score;

  /// How much data backed this score, in [0.0, 1.0]. Low confidence
  /// (e.g. a dropped sensor) should make downstream components more
  /// conservative, not less.
  final double confidence;

  /// Which signals contributed to [score], and by how much.
  /// Unmodifiable.
  final List<SignalContribution> triggeredSignals;

  /// When this result was produced.
  final DateTime timestamp;

  /// The engine's suggested next action. The engine recommends; it
  /// never acts — see [Recommendation].
  final Recommendation recommendation;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is RiskResult &&
          runtimeType == other.runtimeType &&
          score == other.score &&
          confidence == other.confidence &&
          _listEquals(triggeredSignals, other.triggeredSignals) &&
          timestamp == other.timestamp &&
          recommendation == other.recommendation);

  @override
  int get hashCode => Object.hash(
    score,
    confidence,
    Object.hashAll(triggeredSignals),
    timestamp,
    recommendation,
  );

  @override
  String toString() =>
      'RiskResult(score: $score, confidence: $confidence, '
      'triggeredSignals: $triggeredSignals, timestamp: $timestamp, '
      'recommendation: $recommendation)';
}

bool _listEquals<T>(List<T> a, List<T> b) {
  if (identical(a, b)) return true;
  if (a.length != b.length) return false;
  for (var i = 0; i < a.length; i++) {
    if (a[i] != b[i]) return false;
  }
  return true;
}
