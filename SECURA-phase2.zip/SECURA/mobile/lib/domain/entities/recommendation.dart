/// The Risk Detection Engine's suggested next action for a given
/// [RiskResult]. The engine only ever *recommends* — it never triggers
/// anything itself; the Check-in System and Emergency State Machine
/// decide what actually happens. See docs/ARCHITECTURE.md §5.
enum Recommendation {
  /// Nothing unusual — no action needed.
  none,

  /// Slightly elevated signal, not enough to interrupt the user yet.
  monitor,

  /// Elevated enough to ask the user directly: "Are you safe?"
  checkIn,

  /// Signal is severe and specific enough (e.g. a hard fall with no
  /// motion afterwards) that the recommendation is to escalate directly
  /// rather than wait for a check-in response.
  escalate,
}
