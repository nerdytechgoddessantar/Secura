/// One signal's contribution to an overall [RiskResult] score.
///
/// This class only carries the value — it doesn't invent it. Every
/// threshold that feeds a contribution must be documented at the call
/// site that creates it (see docs/ARCHITECTURE.md §5), including its
/// source and known limitations.
class SignalContribution {
  const SignalContribution({
    required this.signalName,
    required this.contribution,
    required this.rawValue,
    this.threshold,
  }) : assert(
         contribution >= 0.0 && contribution <= 1.0,
         'contribution must be in [0.0, 1.0], got $contribution',
       );

  /// Machine-readable identifier, e.g. "heart_rate_spike",
  /// "route_deviation". Used for logging and by the Simulation Mode
  /// dashboard to label which signal fired.
  final String signalName;

  /// This signal's share of the overall [RiskResult.score], in
  /// [0.0, 1.0].
  final double contribution;

  /// The raw sensor value that produced this contribution, kept for
  /// debugging and for the Emergency History screen.
  final Object? rawValue;

  /// The documented threshold this contribution was measured against,
  /// if any. Null for signals that don't use a fixed threshold.
  final double? threshold;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is SignalContribution &&
          runtimeType == other.runtimeType &&
          signalName == other.signalName &&
          contribution == other.contribution &&
          rawValue == other.rawValue &&
          threshold == other.threshold);

  @override
  int get hashCode =>
      Object.hash(signalName, contribution, rawValue, threshold);

  @override
  String toString() =>
      'SignalContribution(signalName: $signalName, '
      'contribution: $contribution, rawValue: $rawValue, '
      'threshold: $threshold)';
}
