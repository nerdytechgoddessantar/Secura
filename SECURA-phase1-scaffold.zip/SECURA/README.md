# SECURA

**Your Safety. Our Priority.**

SECURA is a personal-safety app that watches for unusual combinations of
sensor signals — heart rate, motion, steps, route deviation, fall
signals, smartwatch data — and checks in with the user ("Are you
safe?") before ever assuming something is wrong. If the user asks for
help, or doesn't respond in time, SECURA escalates through a
configurable emergency workflow: notifying emergency contacts, sharing
location, and logging an emergency event.

SECURA does not, and does not claim to, detect specific crimes. Sensor
signals are treated as probabilistic indicators of possible distress,
designed to minimize false positives, always with a human-in-the-loop
check-in step first.

Full system design lives in [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md).

## Tech Stack

| Layer | Technology |
|---|---|
| Mobile | Flutter / Dart |
| Wearable | Android + Wear OS |
| Backend | Python + FastAPI |
| Database | Firebase (initial) → PostgreSQL (planned) |
| ML | Python, NumPy, Pandas, scikit-learn |
| Version control | Git + GitHub |

## Repository Structure

```
SECURA/
├── mobile/           # Flutter app
├── smartwatch/       # Wear OS companion app
├── backend/          # FastAPI service
├── ml/               # Dataset + baseline-vs-ML experiments
├── tests/            # Cross-cutting integration tests
├── docs/             # Architecture & design docs
├── assets/           # Design assets, icons
├── .gitignore
├── README.md
└── LICENSE
```

## Project Status

**Phase 1 — Architecture & repository scaffold.** No application code
yet, by design — see the development process and phase roadmap in
[`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md).

The MVP target is a **simulation-first** build: the entire check-in →
emergency workflow, demoable without any physical wearable or live
backend, using a rule-based Risk Detection Engine and mock emergency
integrations.

## Development Approach

Built incrementally, one phase at a time: architecture → code → tests →
docs → commit, then review before moving on. Real hardware and
third-party integrations are added only after the full workflow already
works in Simulation Mode.

## License

See [`LICENSE`](LICENSE) — currently a placeholder pending a decision
between open-sourcing this as a portfolio project or keeping it
proprietary as a startup product.
