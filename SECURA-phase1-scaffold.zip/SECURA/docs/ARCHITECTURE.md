# SECURA — Architecture & Phase 1 Plan

*"Your Safety. Our Priority."*

This document is the single source of truth for SECURA's system design.
It is written **before any application code**, per the project's own
development process: architecture first, implementation phase by phase.

---

## 1. What SECURA Is (and Isn't)

SECURA is a personal-safety app that watches for **unusual combinations**
of sensor signals (heart rate, motion, steps, route deviation, fall
signals) and, when something looks off, asks the user directly:

> **"Are you safe?"**

If the user confirms they're fine, nothing else happens. If they ask for
help, or don't respond in time, SECURA escalates through a configurable
emergency workflow (notify contacts, share location, log an emergency
event).

**SECURA does not, and must not claim to, detect assault, kidnapping,
harassment, or any specific crime.** Sensors give probabilistic evidence
of *possible distress* — nothing more. Every design decision below is
built around minimizing false positives and never overstating what the
system knows.

---

## 2. MVP Definition

The MVP is **simulation-first** — a complete, demoable emergency workflow
that needs no physical wearable and no live backend.

**In scope for MVP**
- Flutter mobile app running entirely on simulated sensor data
- Rule-based Risk Detection Engine with documented, adjustable thresholds
- "Are you safe?" check-in flow with configurable timeout
- Full Emergency State Machine (see §6)
- **Mock** Emergency Response System — an in-app event log standing in
  for real SMS/contact notification, clearly labeled as mock
- Simulation Mode dashboard to trigger every scenario in the spec
- Emergency History screen (local storage only)
- Settings & Privacy Controls screens (thresholds, opt-ins, timeout)

**Explicitly out of scope for MVP** (deferred to later phases)
- Real Wear OS / smartwatch hardware integration
- Real backend persistence (FastAPI + Firebase)
- Real emergency-service or SMS integration (Twilio, 911, etc.)
- ML-based risk scoring (baseline is rule-based only, by design — see §8)
- Multi-user accounts / authentication

This ordering exists so the entire user experience can be validated —
and demoed for a portfolio or investors — before any dependency on
hardware, cloud infrastructure, or real notification providers exists.

---

## 3. Development Phases (Roadmap)

| Phase | Deliverable |
|---|---|
| 1 | Architecture & repo scaffold (this document — no code) |
| 2 | Core domain layer: `RiskResult`, Emergency State Machine, entities (pure Dart, unit tested) |
| 3 | Sensor provider abstractions + **simulated** implementations (`HeartRateProvider`, `MotionProvider`, `LocationProvider`, `BatteryProvider`, `WearableProvider`) |
| 4 | Rule-based Risk Detection Engine + documented thresholds + unit tests |
| 5 | Mobile UI: Home/Monitoring, Live Sensor Status, Check-in screen |
| 6 | Emergency Alert, Contacts, Location Sharing, History screens + Mock Emergency Response System |
| 7 | Simulation Mode dashboard (every scenario: fall, route deviation, multi-signal, no-response, etc.) |
| 8 | Settings & Privacy Controls, accessibility pass |
| 9 | Backend (FastAPI) + Firebase, replacing local mocks one at a time |
| 10 | Wear OS companion app + real wearable data layer |
| 11 | ML experiment track: dataset, baseline-vs-ML comparison, metrics |
| 12 | Security hardening, encryption at rest, CI/CD, docs polish |

Each phase follows the same loop: explain → architect → build → test →
document what changed → commit. We don't start phase *n+1* until phase
*n* is reviewed.

---

## 4. System Architecture

```
Smartwatch (Wear OS)
   │  heart rate, accel/gyro, steps
   ▼
Wearable Data Layer          (Bluetooth / Wear OS Data Layer API)
   │
   ▼
Mobile Sensor Layer          (phone accel/gyro, GPS, battery + wearable feed)
   │
   ▼
Sensor Normalization         (units, sample-rate alignment, gap handling)
   │
   ▼
Risk Detection Engine        (rule-based baseline → RiskResult)
   │
   ▼
Check-in System              ("Are you safe?", timeout handling)
   │
   ▼
Emergency State Machine      (explicit states, see §6)
   │
   ▼
Emergency Response System    (mock in dev, real integrations behind flags)
```

### Component responsibilities

- **Sensor providers** — one interface per signal source
  (`HeartRateProvider`, `MotionProvider`, `LocationProvider`,
  `BatteryProvider`, `WearableProvider`). Each has a `Simulated*`
  implementation and, later, a `Real*` implementation. Application logic
  never knows which one it's talking to.
- **Sensor Normalization** — resamples/aligns heterogeneous signals into
  a common windowed format the Risk Engine can consume, and flags gaps
  (e.g., watch disconnected) rather than silently interpolating them.
- **Risk Detection Engine** — pure function: normalized window in,
  `RiskResult` out. No side effects, no I/O — this is what makes it
  unit-testable and swappable for an ML model later.
- **Check-in System** — owns the "Are you safe?" UI/notification and the
  configurable response-timeout timer. Knows nothing about *why* a
  check-in was triggered, only that one was requested.
- **Emergency State Machine** — the single authority on what state the
  app is in. Every other component reacts to state changes; nothing
  else mutates state directly.
- **Emergency Response System** — executes the configured workflow for
  the current state. In dev/simulation, every integration
  (contact notification, evidence capture, "call emergency services")
  is a `Mock*` implementation that logs what *would* happen. A real
  implementation is only ever swapped in behind an explicit config flag,
  never silently.

### Data flow

```mermaid
flowchart TD
    A[Smartwatch sensors] -->|BLE / Wear OS Data Layer| B[Wearable Data Layer]
    C[Phone sensors: accel, gyro, GPS, battery] --> D[Mobile Sensor Layer]
    B --> D
    D --> E[Sensor Normalization]
    E --> F[Risk Detection Engine]
    F -->|RiskResult| G{Recommendation}
    G -->|MONITOR| D
    G -->|CHECK_IN| H[Check-in System]
    G -->|ESCALATE| I[Emergency State Machine]
    H -->|I'm Safe| D
    H -->|I Need Help| I
    H -->|Timeout, no response| I
    I --> J[Emergency Response System]
    J --> K[Notify contacts - mock in dev]
    J --> L[Share location / timestamp / battery]
    J --> M[Create emergency event record]
    J --> N[Optional evidence capture - opt-in only]
```

---

## 5. RiskResult — the contract between the engine and everything else

```
RiskResult {
  score: float            // 0.0–1.0, unusualness of the current window
  confidence: float       // 0.0–1.0, how much data backed this score
  triggeredSignals: [SignalContribution]
  timestamp: DateTime
  recommendation: Recommendation   // NONE | MONITOR | CHECK_IN | ESCALATE
}

SignalContribution {
  signalName: string      // e.g. "heart_rate_spike", "route_deviation"
  contribution: float     // this signal's share of the score
  rawValue: any
  threshold: float?       // documented, not hard-coded silently
}
```

Every threshold that feeds into `score` must be documented in code
comments with its source and its known limitations (e.g., "resting HR
spike threshold based on generic population data — not personalized,
not clinically validated"). No threshold ships undocumented.

---

## 6. Emergency State Machine

The spec sketches two related flows plus a set of exception states.
Here they're merged into one machine, with the exception states pulled
out as **orthogonal system-health flags** rather than mutually exclusive
states — because in reality you can be `EMERGENCY_ACTIVE` *and*
`LOW_BATTERY` at the same time, and the machine needs to represent that
without a combinatorial explosion of states.

**Primary states**

```mermaid
stateDiagram-v2
    [*] --> NORMAL
    NORMAL --> POSSIBLE_DISTRESS: risk score > threshold
    POSSIBLE_DISTRESS --> CHECKING_IN: check-in triggered
    POSSIBLE_DISTRESS --> NORMAL: score decays, no check-in needed
    POSSIBLE_DISTRESS --> CANCELLED: user dismisses
    CHECKING_IN --> USER_CONFIRMED_SAFE: "I'm Safe"
    CHECKING_IN --> USER_REQUESTED_HELP: "I Need Help"
    CHECKING_IN --> EMERGENCY_ACTIVE: timeout, no response
    CHECKING_IN --> CANCELLED: user dismisses before timeout
    USER_CONFIRMED_SAFE --> NORMAL
    USER_REQUESTED_HELP --> EMERGENCY_ACTIVE
    EMERGENCY_ACTIVE --> RESOLVED: situation closed
    EMERGENCY_ACTIVE --> FALSE_ALARM: user or trusted contact cancels
    CANCELLED --> NORMAL
    FALSE_ALARM --> NORMAL
    RESOLVED --> NORMAL
```

**Orthogonal system-health flags** (can be true in any primary state):

| Flag | Meaning | Effect |
|---|---|---|
| `SENSOR_UNAVAILABLE` | A required sensor feed dropped | Risk Engine runs on reduced confidence; UI shows degraded mode |
| `NETWORK_UNAVAILABLE` | No connectivity | Emergency Response queues actions (e.g., SMS fallback) instead of failing silently |
| `LOW_BATTERY` | Phone or watch battery critical | Emergency Response prioritizes location-share over less time-critical actions |

Keeping these as flags (not states) means the state machine stays small
and testable, while the UI and Emergency Response System can still react
to degraded conditions correctly.

---

## 7. Privacy & Security Considerations

*(Engineering guidance, not legal advice — recording-consent and data-
protection law varies by jurisdiction; get real legal review before
shipping audio capture or cross-border data storage.)*

- **Data minimization** — raw sensor streams are processed in-memory in
  rolling windows and are **not** persisted unless an emergency event
  actually fires. Only the emergency event record is retained.
- **Encryption** — TLS for everything in transit; at-rest encryption for
  any stored emergency event, contact list, or location history
  (Firebase's infra encryption plus app-level field encryption for the
  most sensitive fields).
- **Explicit opt-in, OS-aligned** — audio recording, always-on location,
  and heart-rate access are each independently opt-in and go through
  the platform's real permission dialogs (Android runtime permissions /
  Health Connect), never a blanket "accept all."
- **Mock vs. real, always labeled** — every emergency integration has a
  `Mock*` and (eventually) a `Real*` implementation, selected by an
  explicit environment flag. The app must never claim "emergency
  services contacted" unless a real, authorized integration is wired up
  and active.
- **Least-privilege sharing** — emergency contacts only receive data
  when an emergency event actually triggers; there's no ambient sharing
  of location or health data outside that path.
- **Audit trail, not surveillance** — emergency events get an immutable
  timestamped record for accountability; day-to-day "normal" activity is
  not logged just because it was observed.

---

## 8. ML Strategy (for Phase 11, noted here so it shapes the architecture now)

- The **rule-based Risk Detection Engine is the real baseline**, not a
  placeholder — it's what ships first, and it's what an ML approach
  will later be measured against, not assumed to beat.
- Synthetic data and any real data are kept in clearly separate,
  labeled datasets — never merged silently.
- Standard train/validation/test splits, with precision, recall, F1, and
  false-positive rate reported for both the baseline and any ML model.
- Class imbalance (true distress events are rare) is called out
  explicitly wherever metrics are reported, since accuracy alone would
  be misleading.
- No clinical or safety-validation claims are made for either approach.

---

## 9. Testing Strategy

| Layer | Tooling | What it covers |
|---|---|---|
| Domain unit tests | `flutter test` | State machine transitions, `RiskResult` scoring logic |
| Backend unit tests | `pytest` | API schemas, mock/real integration selection logic |
| Widget tests | `flutter test` | Check-in, Emergency Alert, Simulation Mode screens |
| Integration tests | `flutter integration_test` | End-to-end: simulate signals → check-in → emergency → resolution |
| ML evaluation | `scikit-learn` metrics, notebooks | Precision/recall/F1/false-positive rate, baseline vs. ML |
| CI | GitHub Actions | `flutter analyze` + `flutter test`, `ruff`/`mypy` + `pytest` on every PR |

---

## 10. Repository Structure

```
SECURA/
├── mobile/           # Flutter app (Phases 2–8)
├── smartwatch/       # Wear OS companion app (Phase 10)
├── backend/          # FastAPI service (Phase 9)
├── ml/               # Dataset + baseline-vs-ML experiments (Phase 11)
├── tests/            # Cross-cutting integration tests
├── docs/
│   └── ARCHITECTURE.md   # this file
├── assets/           # Design assets, icons
├── .gitignore
├── README.md
└── LICENSE
```

Each top-level folder currently holds only a `.gitkeep` — code lands
starting in Phase 2, per the "architecture before implementation" rule.
